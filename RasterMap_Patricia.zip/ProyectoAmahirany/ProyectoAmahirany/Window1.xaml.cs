﻿/*
 * Created by SharpDevelop.
 * User: Patricia Amahirany Osuna Sarmiento
 * Date: 19/05/2024
 * Time: 04:33 p. m.
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.IO;
using System.Windows.Media.Imaging;
using Microsoft.Win32;
using System.Linq;

namespace ProyectoAmahirany {

  public partial class MainWindow: Window {
    private int n = 366; //  archivo .rst
    private int m = 397; //  archivo .rst
    private bool imagenCargada = false;
    private Color[, ] coloredPixels;

    public MainWindow() {
      InitializeComponent();
      buttonBuscar.Click += BtnObtenerVecinos_Click;
      buttonCargar.Click += Button_Click;
    }

    // archivo de entrada contiene datos de bytes con una longitud específica
    private bool IsByteData(string filePath) {
      try {
        // Intenta abrir el archivo especificado en el modo de lectura binaria
        using(BinaryReader reader = new BinaryReader(File.Open(filePath, FileMode.Open))) {
          // Obtiene la longitud del flujo de datos base del lector
          long length = reader.BaseStream.Length;

          // Compara la longitud del archivo con el tamaño esperado de los datos de bytes (366 * 397)
          // Retorna true si la longitud del archivo coincide con el tamaño esperado
          return length == n * m;
        }
      } catch (IOException ex) {
        // Muestra un mensaje de error con el detalle de la excepción en un cuadro de diálogo
        MessageBox.Show("Error reading file: {ex.Message}");

        // Retorna false, indicando que los datos no son del tipo esperado (bytes) o el archivo no se puede leer
        return false;
      }
    }

    private void Button_Click(object sender, RoutedEventArgs e) {
      // Crea un cuadro de diálogo para abrir archivos
      OpenFileDialog openFileDialog = new OpenFileDialog {
        Filter = "Raster Files (*.rst)|*.rst" // Define el filtro de archivos para mostrar solo archivos .rst
      };

      // Si se selecciona un archivo y se hace clic en "Aceptar" en el cuadro de diálogo
      if (openFileDialog.ShowDialog() == true) {
        // Obtiene la ruta del archivo seleccionado
        string filePath = openFileDialog.FileName;

        try {
          // Verifica si el archivo contiene datos de bytes o enteros y procesa los datos en consecuencia
          if (IsByteData(filePath)) {
            // Lee los datos raster del archivo como bytes y los convierte en colores
            var datosRaster = ReadRasterData < byte > (filePath, reader => reader.ReadByte());
            coloredPixels = MapByteRasterToColors(datosRaster);
          } else {
            // Lee los datos raster del archivo como enteros y los convierte en colores
            var datosRaster = ReadRasterData < ushort > (filePath, reader => reader.ReadUInt16());
            coloredPixels = MapIntRasterToColors(datosRaster);
          }

          // Muestra la representación visual del raster en el control de imagen
          DisplayRaster(coloredPixels);
        } catch (Exception ex) {
          MessageBox.Show("Error reading file: {ex.Message}");
        }
      }
      imagenCargada = true;
    }

    private T[, ] ReadRasterData < T > (string filePath, Func < BinaryReader, T > readFunc) {
      // Crea una nueva matriz para almacenar los datos raster
      var datosRaster = new T[n, m];

      // Abre el archivo en modo de lectura binaria utilizando un BinaryReader
      using(BinaryReader reader = new BinaryReader(File.Open(filePath, FileMode.Open))) {
        // Itera sobre cada fila y columna de la matriz
        for (int row = 0; row < n; row++) {
          for (int col = 0; col < m; col++) {
            try {
              // Lee un valor del archivo utilizando la función especificada y lo asigna a la matriz
              datosRaster[row, col] = readFunc(reader);
            } catch (EndOfStreamException) {
              // Si se alcanza el final del archivo antes de leer todos los datos necesarios, lanza una excepción
              throw new Exception("Insufficient data.");
            }
          }
        }
      }

      // Devuelve la matriz que contiene los datos raster leídos del archivo
      return datosRaster;
    }

    private Color[, ] MapByteRasterToColors(byte[, ] datosRaster) {
      // Crea una nueva matriz para almacenar los colores resultantes
      var coloredPixels = new Color[n, m];

      // Define una lista de colores predefinidos para asignar a los valores de datos raster
      var categoryColors = new List < Color > {
        Colors.Purple,
        Colors.Orange,
        Colors.Pink,
        Colors.Teal,
        Colors.Brown,
        Colors.Lime,
        Colors.Magenta,
        Colors.Navy,
        Colors.Yellow
      };

      // Itera sobre cada fila y columna de la matriz de datos raster
      for (int row = 0; row < n; row++) {
        for (int col = 0; col < m; col++) {
          // Obtiene el valor de datos raster en la posición actual
          byte value = datosRaster[row, col];

          // Asigna un color basado en el valor de datos raster utilizando la lista de colores predefinidos
          // Si el valor está dentro del rango de 1 a 9, se asigna el color correspondiente de la lista;
          // de lo contrario, se asigna el color gris.
          coloredPixels[row, col] = (value >= 1 && value <= 9) ? categoryColors[value - 1] : Colors.Gray;
        }
      }

      // Devuelve la matriz de colores que representa los datos raster
      return coloredPixels;
    }

    private Color[, ] MapIntRasterToColors(ushort[, ] datosRaster) {
      // Crea una nueva matriz para almacenar los colores resultantes
      var coloredPixels = new Color[n, m];

      // Define una lista de colores predefinidos para asignar a los valores de datos raster
      var categoryColors = new List < Color > {
        Colors.Indigo,
        Colors.Red,
        Colors.Turquoise,
        Colors.Olive,
        Colors.Green,
        Colors.Lavender,
        Colors.Crimson,
        Colors.Gold,
        Colors.Aquamarine,
        Colors.Chocolate,
        Colors.Maroon,
        Colors.Chartreuse,
        Colors.Silver,
        Colors.Blue,
        Colors.SkyBlue,
        Colors.Purple,
        Colors.Magenta,
        Colors.Coral
      };

      // Itera sobre cada fila y columna de la matriz de datos raster
      for (int row = 0; row < n; row++) {
        for (int col = 0; col < m; col++) {
          // Obtiene el valor de datos raster en la posición actual
          ushort value = datosRaster[row, col];

          // Asigna un color basado en el valor de datos raster utilizando la lista de colores predefinidos
          // Si el valor está dentro del rango de 1 a 18, se asigna el color correspondiente de la lista;
          // de lo contrario, se asigna el color gris.
          coloredPixels[row, col] = (value >= 1 && value <= 18) ? categoryColors[value - 1] : Colors.Gray;
        }
      }

      // Devuelve la matriz de colores que representa los datos raster
      return coloredPixels;
    }

    private void DisplayRaster(Color[, ] coloredPixels) {
      // Obtiene el ancho y alto de la matriz de colores
      int width = coloredPixels.GetLength(1);
      int height = coloredPixels.GetLength(0);

      // Crea un nuevo objeto WriteableBitmap para representar los datos raster en formato de imagen
      WriteableBitmap bitmap = new WriteableBitmap(width, height, 96, 96, PixelFormats.Bgr32, null);

      // Crea un array de bytes para almacenar los datos de los píxeles de la imagen
      byte[] pixelData = new byte[width * height * 4];

      // Itera sobre cada fila y columna de la matriz de colores
      for (int row = 0; row < height; row++) {
        for (int col = 0; col < width; col++) {
          // Calcula el índice del píxel en el array de bytes
          int pixelIndex = (row * width + col) * 4;

          // Asigna los componentes de color del píxel en el array de bytes
          pixelData[pixelIndex + 0] = coloredPixels[row, col].B; // Componente azul
          pixelData[pixelIndex + 1] = coloredPixels[row, col].G; // Componente verde
          pixelData[pixelIndex + 2] = coloredPixels[row, col].R; // Componente rojo
          pixelData[pixelIndex + 3] = 255; // Componente alfa (opacidad)
        }
      }

      // Escribe los datos de los píxeles en el objeto WriteableBitmap
      bitmap.WritePixels(new Int32Rect(0, 0, width, height), pixelData, width * 4, 0);

      // Asigna la imagen al control de imagen en la interfaz de usuario
      imageControl.Source = bitmap;
    }

    private void BtnObtenerVecinos_Click(object sender, RoutedEventArgs e) {
      // Verifica si se ha cargado una imagen antes de buscar vecinos
      if (!imagenCargada) {
        MessageBox.Show("You must upload an image before searching for neighbors.");
        return;
      }

      // Variables para almacenar las coordenadas de entrada
      int cordenadaX, cordenadaY;

      // Intenta convertir el texto de las cajas de texto en coordenadas enteras
      if (int.TryParse(textBoxX.Text, out cordenadaX) && int.TryParse(textBoxY.Text, out cordenadaY)) {
        // Verifica si las coordenadas están dentro del rango de la matriz
        if (cordenadaX >= 0 && cordenadaX < n && cordenadaY >= 0 && cordenadaY < m) {
          // Variable para almacenar el radio de búsqueda de vecinos
          int radio;

          // Intenta convertir el texto de la caja de texto de radio en un número entero no negativo
          if (int.TryParse(textBoxRadio.Text, out radio) && radio >= 0) {
            // Obtiene la lista de vecinos para la posición especificada y el radio dado
            List < string > vecinos = ObtenerVecinos(cordenadaX, cordenadaY, radio);

            // Limpia el contenido de la lista de vecinos antes de agregar los nuevos vecinos
            listBoxVecinos.Items.Clear();

            // Agrega cada vecino a la lista de vecinos
            foreach(string vecino in vecinos) {
              listBoxVecinos.Items.Add(vecino);
            }
          } else {
            MessageBox.Show("Please enter a valid radius (non-negative integer).");
          }
        } else {
          MessageBox.Show("Coordinates must be within the range of the array.");
        }
      } else {
        MessageBox.Show("Enter valid coordinates (whole numbers).");
      }
    }

    private List < string > ObtenerVecinos(int cordenadaX, int cordenadaY, int radio) {
      // Lista para almacenar las coordenadas de los vecinos
      List < string > vecinos = new List < string > ();

      // Itera sobre las posiciones dentro del radio alrededor de la posición central
      for (int i = cordenadaX - radio; i <= cordenadaX + radio; i++) {
        for (int j = cordenadaY - radio; j <= cordenadaY + radio; j++) {
          // Verifica si la posición está dentro de la matriz y no es la posición central
          if (i >= 0 && i < n && j >= 0 && j < m && !(i == cordenadaX && j == cordenadaY)) {
            // Agrega la coordenada del vecino a la lista de vecinos
            vecinos.Add(string.Format("[{0}, {1}]", i, j));
          }
        }
      }

      // Retorna la lista de vecinos
      return vecinos;
    }
}
}